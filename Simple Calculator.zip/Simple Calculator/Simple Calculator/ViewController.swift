//
//  ViewController.swift
//  Simple Calculator
//
//  Created by Khai Nguyen on 9/7/25.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    
    @IBOutlet weak var textFieldA: UITextField!
    @IBOutlet weak var textFieldB: UITextField!
    @IBOutlet weak var operationSegment: UISegmentedControl!
    @IBOutlet weak var tableView: UITableView!
    
    // Biến trạng thái: true = nhập a, false = nhập b
    var isInputA = true
    
    // Mảng lưu kết quả
    var results: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        textFieldA.delegate = self
        textFieldB.delegate = self
        updateInputState()
    }
    
    //Phím số 0-9
    @IBAction func numberButtonTapped(_ sender: UIButton) {
        guard let numberText = sender.titleLabel?.text else { return }
        if isInputA {
            let newText = (textFieldA.text ?? "") + numberText
            if let value = Double(newText), value.truncatingRemainder(dividingBy: 1) == 0 {
                textFieldA.text = String(Int(value))
            } else {
                textFieldA.text = newText
            }
        } else {
            let newText = (textFieldB.text ?? "") + numberText
            if let value = Double(newText), value.truncatingRemainder(dividingBy: 1) == 0 {
                textFieldB.text = String(Int(value))
            } else {
                textFieldB.text = newText
            }
        }
    }
    
    //Phím xoá
    @IBAction func deleteButtonTapped(_ sender: UIButton) {
        if isInputA {
            if let text = textFieldA.text, !text.isEmpty {
                let newText = String(text.dropLast())
                if let value = Double(newText), value.truncatingRemainder(dividingBy: 1) == 0 {
                    textFieldA.text = String(Int(value))
                } else {
                    textFieldA.text = newText
                }
            }
        } else {
            if let text = textFieldB.text, !text.isEmpty {
                let newText = String(text.dropLast())
                if let value = Double(newText), value.truncatingRemainder(dividingBy: 1) == 0 {
                    textFieldB.text = String(Int(value))
                } else {
                    textFieldB.text = newText
                }
            }
        }
    }
    
    //Phím chuyển đổi
    @IBAction func switchInputTapped(_ sender: UIButton) {
        isInputA.toggle()
        updateInputState()
    }
    
    // Đổi màu hoặc border để biết đang nhập ô nào
    func updateInputState() {
        if isInputA {
            textFieldA.layer.borderWidth = 3
            textFieldA.layer.borderColor = UIColor.systemYellow.cgColor
            textFieldB.layer.borderWidth = 0
        } else {
            textFieldB.layer.borderWidth = 3
            textFieldB.layer.borderColor = UIColor.systemYellow.cgColor
            textFieldA.layer.borderWidth = 0
        }
    }
    
    //Phím tính toán
    @IBAction func calculateTapped(_ sender: UIButton) {
        guard let aText = textFieldA.text, let bText = textFieldB.text,
              let a = Double(aText), let b = Double(bText) else {
            results.insert("Vui lòng nhập đủ số!", at: 0)
            tableView.reloadData()
            return
        }
        
        let opIndex = operationSegment.selectedSegmentIndex
        var result: Double = 0
        var opSymbol = ""
        var resultString = ""
        // Định dạng a và b
        let aStr: String = a.truncatingRemainder(dividingBy: 1) == 0 ? String(Int(a)) : String(a)
        let bStr: String = b.truncatingRemainder(dividingBy: 1) == 0 ? String(Int(b)) : String(b)
        switch opIndex {
        case 0:
            result = a + b
            opSymbol = "+"
            if result.truncatingRemainder(dividingBy: 1) == 0 {
                resultString = "\(aStr) \(opSymbol) \(bStr) = \(Int(result))"
            } else {
                resultString = "\(aStr) \(opSymbol) \(bStr) = \(result)"
            }
        case 1:
            result = a - b
            opSymbol = "-"
            if result.truncatingRemainder(dividingBy: 1) == 0 {
                resultString = "\(aStr) \(opSymbol) \(bStr) = \(Int(result))"
            } else {
                resultString = "\(aStr) \(opSymbol) \(bStr) = \(result)"
            }
        case 2:
            result = a * b
            opSymbol = "×"
            if result.truncatingRemainder(dividingBy: 1) == 0 {
                resultString = "\(aStr) \(opSymbol) \(bStr) = \(Int(result))"
            } else {
                resultString = "\(aStr) \(opSymbol) \(bStr) = \(result)"
            }
        case 3:
            opSymbol = "÷"
            if b == 0 {
                results.insert("Không thể chia cho 0!", at: 0)
                tableView.reloadData()
                return
            }
            result = a / b
            resultString = "\(aStr) \(opSymbol) \(bStr) = \(result)"
        default:
            break
        }
        results.insert(resultString, at: 0)
        tableView.reloadData()
    }
    

    
    // MARK: - TableView DataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return results.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.text = results[indexPath.row]
        return cell
    }
    
    @IBAction func clearHistoryTapped(_ sender: UIButton) {
        results.removeAll()
        tableView.reloadData()
    }
    
}

extension ViewController: UITextFieldDelegate {
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == textFieldA {
            isInputA = true
        } else if textField == textFieldB {
            isInputA = false
        }
        updateInputState()
        return false // Không cho phép bàn phím hiện lên
    }
}

