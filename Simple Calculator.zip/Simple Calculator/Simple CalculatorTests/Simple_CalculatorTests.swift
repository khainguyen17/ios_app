//
//  Simple_CalculatorTests.swift
//  Simple CalculatorTests
//
//  Created by Khai Nguyen on 9/7/25.
//

import Testing
@testable import Simple_Calculator

struct Simple_CalculatorTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
